﻿using System.Collections.Generic;

public class AgentActionTester2 : AgentAction
{
    protected override List<Parameter> GetParameters()
    {
        return new List<Parameter>();
    }
}